﻿namespace RMSuit_v2.Models
{
    public class Employee
    {
        public int empleado1 { get; set; }
        public string nombre { get; set; } = string.Empty;
        public string direccion { get; set; }
        public string poblacion { get; set; }
        public string telefono { get; set; }
        public string clave { get; set; }
        public string rango { get; set; }
        public int nivel { get; set; }
    }
}
