﻿namespace PruebaConBlazor.Models
{
    public enum TipoImagen
    {
        Modificada,
        Disponible,
        EnServicio,
        Facturada,
        Refacturada
    }
}
