﻿using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using System.Reflection;

namespace RMSuit_v2.Services
{
    public class CustomStringLocalizerFactory : ResourceManagerStringLocalizerFactory
    {
        public CustomStringLocalizerFactory(IOptions<LocalizationOptions> localizationOptions, ILoggerFactory loggerFactory)
            : base(localizationOptions, loggerFactory)
        {
        }

        protected override string GetResourcePrefix(TypeInfo typeInfo)
        {
            // Obtener el nombre de la clase (que coincide con el nombre de la página)
            var className = typeInfo.Name;

            var resourcePath = $"RMSuit_v2.Components.Resources.lang.{className}.{className}";

            return resourcePath;
        }
    }
}
