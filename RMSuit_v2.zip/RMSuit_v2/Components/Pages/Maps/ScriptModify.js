﻿let selectedElement = null;
let offset = { x: 0, y: 0 };

function startDragging(dibujoId) {
    selectedElement = document.getElementById(`dibujo-${dibujoId}`);
    if (!selectedElement) return;

    selectedElement.style.position = "absolute";

    document.onmousemove = function (event) {
        event.preventDefault();
        offset.x = event.clientX - selectedElement.getBoundingClientRect().left;
        offset.y = event.clientY - selectedElement.getBoundingClientRect().top;

        let newX = event.clientX - offset.x;
        let newY = event.clientY - offset.y;

        selectedElement.style.left = newX + "px";
        selectedElement.style.top = newY + "px";
    };

    document.onmouseup = function () {
        if (selectedElement) {
            let dibujoId = selectedElement.id.split('-')[1];
            let newX = parseInt(selectedElement.style.left);
            let newY = parseInt(selectedElement.style.top);

            DotNet.invokeMethodAsync('RMSuit_v2', 'UpdatePosition', parseInt(dibujoId), newX, newY);
        }
        document.onmousemove = null;
        document.onmouseup = null;
        selectedElement = null;
    };
}
