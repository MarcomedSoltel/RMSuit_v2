﻿namespace RMSuit_v2.Models
{
    public class Drawing
    {
        public int dibujos { get; set; }
        public string estado { get; set; }
        public string grafico { get; set; }
        public string activo { get; set; }
        public string transparente { get; set; }
    }
}
