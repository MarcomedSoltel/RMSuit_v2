using Microsoft.Extensions.Localization;
using Microsoft.AspNetCore.Localization;
using System.Globalization;
using PruebaConBlazor.Constants;
using RMSuit_v2.Components;
using RMSuit_v2.Services.Camareros;
using RMSuit_v2.Services.Dibujos;
using RMSuit_v2.Services.Empleados;
using RMSuit_v2.Services.Salones;
using RMSuit_v2.Services;
using Microsoft.Extensions.Options;


var builder = WebApplication.CreateBuilder(args);

// Localizar idioma
builder.Services.AddLocalization(options => options.ResourcesPath = "Components/Resources/");

builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    var supportedCultures = new[] { new CultureInfo("es"), new CultureInfo("en") };
    options.DefaultRequestCulture = new RequestCulture("es", "es");
    options.SupportedCultures = supportedCultures;
    options.SupportedUICultures = supportedCultures;


    options.RequestCultureProviders = new List<IRequestCultureProvider>
    {
        new QueryStringRequestCultureProvider(), // Para capturar cultura desde la cadena de consulta
    };
});

builder.Services.AddServerSideBlazor()
        .AddCircuitOptions(options =>
        {
            options.DetailedErrors = true;
        });

builder.Services.AddHttpContextAccessor();


builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddHttpClient();

// Servicios especificos
builder.Services.AddScoped<CamarerosService>();
builder.Services.AddScoped<EmpleadosService>();
builder.Services.AddScoped<DibujosService>();
builder.Services.AddScoped<SalonesService>();
builder.Services.AddScoped<ApiService>();


var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

// Para controlar los lenguajes:
app.UseRequestLocalization(app.Services.GetRequiredService<IOptions<RequestLocalizationOptions>>().Value);

app.Use(async (context, next) =>
{
    var cultureQuery = context.Request.Query["culture"].ToString();
    if (!string.IsNullOrEmpty(cultureQuery))
    {
        try
        {
            var culture = new CultureInfo(cultureQuery);
            var requestCulture = new RequestCulture(culture);
            context.Features.Set<IRequestCultureFeature>(new RequestCultureFeature(requestCulture, null));
            context.Response.Headers["Content-Language"] = culture.Name;
        }
        catch (CultureNotFoundException)
        {
            // Manejar caso si la cultura no es v�lida
        }
    }
    await next();
});

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
