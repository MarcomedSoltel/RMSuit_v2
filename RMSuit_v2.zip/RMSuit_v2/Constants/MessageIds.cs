﻿namespace PruebaConBlazor.Constants
{
    public static class MessageIds
    {
        public const int CM_RESTORE = 0x0400 + 0x1000;  // WM_USER + $1000
    }
}
